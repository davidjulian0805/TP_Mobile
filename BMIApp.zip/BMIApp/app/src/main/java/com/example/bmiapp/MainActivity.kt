package com.example.bmiapp

import android.os.Build.VERSION_CODES.S
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.Firebase
import com.google.firebase.database.database

class MainActivity : AppCompatActivity() {
    data class Users (val firstname: String, val middlename: String, val lastname: String, val gender: String,
                      val studentid: String, val course: String)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val fname : EditText = findViewById(R.id.firstName_txt)
        val mname : EditText = findViewById(R.id.MiddleName_txt)
        val lname : EditText = findViewById(R.id.LastName_txt)
        val gender : EditText = findViewById(R.id.Gender_txt)
        val studID : EditText = findViewById(R.id.student_ID)
        val course : EditText = findViewById(R.id.course_txt)
        val submit : Button = findViewById(R.id.submitBtn)

        val database = Firebase.database
        val studentDB = database.getReference("Students")

        submit.setOnClickListener(){

            val FirstName = fname.text.toString().trim()
            val MiddleName = mname.text.toString().trim()
            val LastName = lname.text.toString().trim()
            val Gender = gender.text.toString().trim()
            val StudentID = studID.text.toString().trim()
            val Course = course.text.toString().trim()


            val user = Users(FirstName, MiddleName, LastName, Gender, StudentID, Course)
            studentDB.push().setValue(user)
            Toast.makeText(this, "Registered Successfully",Toast.LENGTH_SHORT).show()
        }
        }
    }
